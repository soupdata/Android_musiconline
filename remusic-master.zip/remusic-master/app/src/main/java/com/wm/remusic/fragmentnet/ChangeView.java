package com.wm.remusic.fragmentnet;

/**
 * Created by wm on 2016/5/31.
 */
public interface ChangeView {
    void changeTo(int page);
}
