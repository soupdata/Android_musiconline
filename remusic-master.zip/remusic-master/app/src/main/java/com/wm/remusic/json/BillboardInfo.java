package com.wm.remusic.json;

/**
 *
 */
public class BillboardInfo {
    public String title;
    public String author;
    public String id;
}
